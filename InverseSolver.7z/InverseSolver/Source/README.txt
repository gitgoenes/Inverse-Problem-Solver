lmain.f
memory.f
elimlib.f
mamoc.f
elem*.f
